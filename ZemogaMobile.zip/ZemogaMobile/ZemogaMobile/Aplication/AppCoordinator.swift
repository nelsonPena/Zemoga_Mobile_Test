//
//  AppCoordinator.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 29/07/21.
//

import Foundation
import UIKit

/**
  AppCoordinator
 
  The application coordinator controls the flow of the application. It installs and navigates between vision controllers, keeping them separate and independent from each other.*
 
  * func start(): Show the first controller
  * func showDetail(): Shows the controller details for the object
  * func showError(): Shows an error depending on the case
 */

class AppCoordinator {
    private let rootViewContoller: UINavigationController
    
    init(rootViewContoller: UINavigationController) {
        self.rootViewContoller = rootViewContoller
    }
    
    func start() {
        showMain()
    }
    
    private func showMain() {
        let postListVC = PostListViewController.instantiate()
        postListVC.configure(didSelectRowAction: { [unowned self] post  in
            showDetail(post: post)
        }, onFailedAction: { error in
            print("❌ Error: \(error)")
        })
        rootViewContoller.setViewControllers([postListVC], animated: true)
    }
    
    private func showDetail(post postEntity: PostsEntity){
        let postDetailVC = PostDetailViewController.instantiate()
        postDetailVC.configure(post: postEntity)
        postDetailVC.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Volver", style: .plain, target: nil, action: nil)
        rootViewContoller.pushViewController(postDetailVC, animated: true)
    }
    
}
