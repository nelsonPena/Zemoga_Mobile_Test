//
//  Color+Name.swift
//  Findme
//
//  Created by Nelson Peña on 15/09/21.
//

import Foundation

/// A class used for logging to console.
class Log {
    
    #if DEBUG
    private static let loggingLevel: Level = .debug
    #else
    private static let loggingLevel: Level = .none
    #endif
    
    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ssZ"
        return formatter
    }()
    
    static func debug(_ message: String, force: Bool = false, file: String = #file, line: Int = #line) {
        log(level: .debug, message, force: force, file: file, line: line)
    }
    
    static func info(_ message: String, force: Bool = false, file: String = #file, line: Int = #line) {
        log(level: .info, message, force: force, file: file, line: line)
    }
    
    static func warning(_ message: String, force: Bool = false, file: String = #file, line: Int = #line) {
        log(level: .warning, message, force: force, file: file, line: line)
    }
    
    static func error(_ message: String, error: Error? = nil, force: Bool = false, file: String = #file, line: Int = #line) {
        let formattedMessage = error != nil ? "\(message) Error: \(error!.localizedDescription)" : message
        log(level: .error, formattedMessage, force: force, file: file, line: line)
    }
    
    private static func log(level: Level, _ message: String, force: Bool, file: String, line: Int) {
        guard force || level.rawValue >= loggingLevel.rawValue else { return }
        let filename = URL(fileURLWithPath: file).deletingPathExtension().lastPathComponent
        print("\(dateFormatter.string(from: Date())) \(filename):\(line) [\(level.tag)] :: \(message)")
    }
    
    private init() { }
    
    private enum Level: UInt {
        case verbose = 1
        case debug = 2
        case info = 3
        case warning = 4
        case error = 5
        case none = 9999
        
        var tag: String {
            switch self {
            case .verbose:
                return "VERBOSE"
            case .debug:
                return "DEBUG"
            case .info:
                return "INFO"
            case .warning:
                return "WARNING"
            case .error:
                return "ERROR"
            case .none:
                return "NONE"
            }
        }
    }
}
