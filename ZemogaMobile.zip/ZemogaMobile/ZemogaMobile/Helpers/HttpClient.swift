//
//  HttpClient.swift
//  YT-Vapor-iOS-App
//
//  Created by Mikaela Caron on 10/19/21.
//

import Foundation

enum HttpMethods: String {
    case POST, GET, PUT, DELETE
}

enum MIMEType: String {
    case JSON = "application/json"
}

enum HttpHeaders: String {
    case contentType = "Content-Type"
}

enum HttpError: Error {
    case badURL, badResponse, errorDecodingData, invalidURL
}

enum JSONError: Error {
    case errorSerialization, errorParceJSON
}

protocol HTTPClientProtocol {
    func fetch<T: Codable>(url: URL) async throws -> [T]
    func fetch(url: URL) async throws -> [String: Any]
}

class HttpClient: HTTPClientProtocol {
    func fetch(url: URL) async throws -> [String: Any] {
        let (data, response) = try await URLSession.shared.data(from: url)
        var jsonData: [String: Any] = [:]
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw HttpError.badResponse
        }
        guard  let jsonResponse = try? JSONSerialization.jsonObject(with:data, options: []) else {
            throw JSONError.errorSerialization
        }
        if let jData = jsonResponse as? [String: Any] {
            jsonData = jData
        }
        return jsonData
    }
    
    func fetch<T: Codable>(url: URL) async throws -> [T] {
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw HttpError.badResponse
        }
        
        guard let object = try? JSONDecoder().decode([T].self, from: data) else {
            throw HttpError.errorDecodingData
        }
        return object
    }
    
}
