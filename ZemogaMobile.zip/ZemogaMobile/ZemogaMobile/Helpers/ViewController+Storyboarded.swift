//
//  Color+Name.swift
//  Findme
//
//  Created by Nelson Peña on 15/09/21.
//

import UIKit

/// A protocol used for instantiating a view controller from a storyboard.
protocol Storyboarded {
    static func instantiate(fromStoryboardNamed: String) -> Self
}

/// An extension with default implementation used for instantiating a view controller from a storyboard.
extension Storyboarded where Self: UIViewController {
    static func instantiate(fromStoryboardNamed storyboardName: String = "Main") -> Self {
        let fullName = NSStringFromClass(self)
        let className = fullName.components(separatedBy: ".")[1]
        let storyboard = UIStoryboard(name: storyboardName, bundle: Bundle.main)
        return storyboard.instantiateViewController(withIdentifier: className) as! Self
    }
}
