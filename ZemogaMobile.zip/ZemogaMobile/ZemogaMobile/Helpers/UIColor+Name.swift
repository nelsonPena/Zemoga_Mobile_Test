//
//  Color+Name.swift
//  Findme
//
//  Created by Nelson Peña on 15/09/21.
//

import UIKit

extension UIColor {
    static let accentColor = UIColor(named: "AccentColor")
}
