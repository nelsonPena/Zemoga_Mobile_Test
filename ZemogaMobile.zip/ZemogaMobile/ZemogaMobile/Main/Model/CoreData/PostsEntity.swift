//
//  Suggestions.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation
import CoreData

final class PostsEntity: NSManagedObject, Identifiable {
   
    @NSManaged var title: String
    @NSManaged var postBody: String
    @NSManaged var idPost: Int16
    @NSManaged var userId: Int16
    @NSManaged var isFavorite: Int16

}
