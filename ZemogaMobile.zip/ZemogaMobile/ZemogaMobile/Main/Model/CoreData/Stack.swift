//
//  Stack.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation
import CoreData

/**
   NSPersistentContainer simplifies the creation and management of the Core Data stack by handling the creation of the managed object model
  `NSManagedObjectModel`, persistent store coordinator `NSPersistentStoreCoordinator`, and the managed object context
  `NSManagedObjectContext'.
 
    [NSPersistentStoreCoordinator.](https://developer.apple.com/documentation/coredata/nspersistentcontainer)
 */

final class PersistentContainer: NSPersistentContainer {

    static let shared = PersistentContainer(name: "DataModel", managedObjectModel: .sharedModel)
  
    func setup() {
        loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
             
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })

        viewContext.mergePolicy = NSMergeByPropertyStoreTrumpMergePolicy

    }
}
