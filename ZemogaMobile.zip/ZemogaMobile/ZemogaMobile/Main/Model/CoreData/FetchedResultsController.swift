//
//  FetchedResultsController.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation
import CoreData

/**
  A controller that is used to handle the results of a parent fetch request and to display data to the user.
 */
extension NSFetchedResultsController {
    /// Static function that extends date results controller,
    /// in which the results are listed and assigned to the `NSFetchedResultsController`
    @objc static func postAllFetchedResultsController() -> NSFetchedResultsController<PostsEntity> {
 
        let fetchRequest = PostsEntity.listAllFetchRequest()

        return NSFetchedResultsController<PostsEntity>(fetchRequest: fetchRequest, managedObjectContext: PersistentContainer.shared.viewContext, sectionNameKeyPath: nil, cacheName: nil)
    }
}
