//
//  StatsFetching.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation
import CoreData

/**
 Extends `suggestions` object, adding filter function by name
 */
extension PostsEntity {
    /// Filter saved results by name, using the contains function.
    /// - returns: suggestion list `[Suggestions]`.
    static func isPostFavorite(by id: Int16, in context: NSManagedObjectContext) -> Bool {
        let fetchRequest = PostsEntity.fetchRequest()
        let p1 = NSPredicate(format: "%K = %ld", #keyPath(PostsEntity.idPost), id)
        let p2 = NSPredicate(format: "isFavorite = 1")
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [p1, p2])
        fetchRequest.predicate = predicate
        print(try! context.count(for: fetchRequest))
        return try! context.count(for: fetchRequest) > 0
    }
    
    static func exists(by id: Int16, in context: NSManagedObjectContext) -> Bool {
        let fetchRequest: NSFetchRequest<PostsEntity>  = PostsEntity.fetchRequest
        return try! (context.fetch(fetchRequest).filter{$0.idPost == id}.count > 0)
    }
    
    static func exists(in context: NSManagedObjectContext) -> Bool {
        let fetchRequest: NSFetchRequest<PostsEntity>  = PostsEntity.fetchRequest
        return try! context.count(for: fetchRequest) > 0
    }
    
    static func get(by postId: Int16, in context: NSManagedObjectContext) -> PostsEntity {
        let fetchRequest: NSFetchRequest<PostsEntity>  = PostsEntity.fetchRequest
        fetchRequest.predicate = NSPredicate(format: "%K = %ld", #keyPath(PostsEntity.idPost), postId)
        var postsEntity : PostsEntity?
        if try! context.count(for: fetchRequest) > 0 {
            postsEntity = try! (context.fetch(fetchRequest).first! as PostsEntity)
        }
        return postsEntity ?? PostsEntity()
    }
    
    static func addNew(post: Post) {
        let suggestions = PostsEntity(context: PersistentContainer.shared.viewContext)
        suggestions.title = post.title
        suggestions.postBody = post.body
        suggestions.idPost = post.id
        suggestions.userId = post.userId
        do {
            try PersistentContainer.shared.viewContext.saveIfNeeded()
        } catch {
            PersistentContainer.shared.viewContext.delete(suggestions)
            print("No save data")
        }
    }
    
    static func listAllFavoritesFetchRequest(in context: NSManagedObjectContext) -> [PostsEntity]  {
        let fetchRequest: NSFetchRequest<PostsEntity>  = PostsEntity.fetchRequest
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: #keyPath(PostsEntity.objectID), ascending: false)]
        fetchRequest.predicate = NSPredicate(format: "isFavorite = 1")
        fetchRequest.propertiesToFetch = [
            #keyPath(PostsEntity.title)
        ]
        return try! (context.fetch(fetchRequest) as [PostsEntity])
    }
    
}
