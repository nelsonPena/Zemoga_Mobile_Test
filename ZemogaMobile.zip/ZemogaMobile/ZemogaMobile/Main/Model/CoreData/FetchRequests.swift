//
//  FetchRequests.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation
import CoreData

extension PostsEntity {
    
    @objc static func listAllFetchRequest() -> NSFetchRequest<PostsEntity> {
        let fetchRequest = PostsEntity.fetchRequest

        // ORDER BY t0.ZOBJETID, Since in this way we can place first, the last printed results
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: #keyPath(PostsEntity.objectID), ascending: false)]

        fetchRequest.propertiesToFetch = [
            #keyPath(PostsEntity.title)
        ]
        print(try!  PersistentContainer.shared.viewContext.count(for: fetchRequest) )
        return fetchRequest
    }
}

/// Defines a convenience class for `NSManagedObject` types to add common methods and remove boilerplate code.
public protocol Managed: NSFetchRequestResult {
    static var entityName: String { get }
}

extension NSManagedObject: Managed { }
public extension Managed where Self: NSManagedObject {
    /// Returns a `String` of the entity name.
    static var entityName: String { return String(describing: self) }

    /// Creates a `NSFetchRequest` which can be used to fetch data of this type.
    static var fetchRequest: NSFetchRequest<Self> {
        return NSFetchRequest<Self>(entityName: entityName)
    }
}
