//
//  Comments.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 31/05/22.
//

import Foundation

struct Comments: Codable {
    let postId: Int
    let id: Int
    let name: String
    let email: String
    let body: String
}
