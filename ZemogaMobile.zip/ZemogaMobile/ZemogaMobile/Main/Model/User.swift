//
//  User.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 30/05/22.
//

import Foundation



struct User {
    
    internal init(id: Int16 = 0, name: String = "", username: String = "", email: String = "", address: [String : Any] = [:], phone: String = "", website: String = "", company: [String : Any] = [:]) {
        self.id = id
        self.name = name
        self.username = username
        self.email = email
        self.address = address
        self.phone = phone
        self.website = website
        self.company = company
    }
     let id: Int16
     let name: String
     let username: String
     let email: String
     let address: [String: Any]
     let phone: String
     let website: String
     let company: [String: Any]
}
