//
//  Item.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import UIKit

/**
 This class is used to list the data to be used in the table, using a unique identifier `UUID`
 */
class Item: Hashable {
    
    internal init(title: String = "", body: String = "", id: Int16 = 0) {
        self.title = title
        self.body = body
        self.id = id
    }
    
    let title: String
    let body: String
    let id: Int16
    let identifier = UUID()
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(identifier)
    }
    
    static func == (lhs: Item, rhs: Item) -> Bool {
        return lhs.identifier == rhs.identifier
    }
}
