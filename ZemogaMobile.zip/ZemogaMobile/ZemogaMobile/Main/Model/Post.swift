//
//  List.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 29/05/22.
//

import Foundation

struct Post: Codable {
    let userId: Int16
    let id: Int16
    let title: String
    let body: String
}
