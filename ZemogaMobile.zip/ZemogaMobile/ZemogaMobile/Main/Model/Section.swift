//
//  Section.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation

enum Section: CaseIterable {
    case favorites
    case main
}
