//
//  SearchError.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 14/04/22.
//

enum SearchError: Error {
    case timeout
    case serverRequestError
    case internalError
}


enum TableError: Error {
    case noDataToShow
}

enum CoreDataError: Error {
    case noSaveData
}
