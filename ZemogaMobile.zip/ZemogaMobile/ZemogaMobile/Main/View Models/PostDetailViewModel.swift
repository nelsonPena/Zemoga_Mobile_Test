//
//  ViewModelList.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 29/05/22.
//

import Foundation

class PostDetailViewModel {
    var refreshUserData = { () -> () in }
    var refreshComments = { () -> () in }
    
    @Published var user: User = User(){
        didSet {
            refreshUserData()
        }
    }
    
    @Published var comments: [Comments] = [] {
        didSet {
            refreshComments()
        }
    }
    
    var httpClient: HTTPClientProtocol!
    
    init(httpClient: HTTPClientProtocol){
        self.httpClient = httpClient
    }
    
    func fetchUser(by userId: Int16) async throws {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let plistData = NSDictionary(contentsOfFile: filePath ?? "")
        let urlString = "\(plistData!["url_user_detail"] as? String ?? "")\(userId)"
        
        guard let url = URL(string: urlString) else {
            throw HttpError.badURL
        }
        
        let jsonResponse = try await httpClient.fetch(url: url)
        
        DispatchQueue.main.async {
            self.user = User(id: (jsonResponse["id"] as? Int16 ?? 0),
                             name: (jsonResponse["name"] as? String ?? ""),
                             username: (jsonResponse["username"] as? String ?? ""),
                             email: (jsonResponse["email"] as? String ?? ""),
                             address: (jsonResponse["address"] as? [String:Any] ?? [:]),
                             phone: (jsonResponse["phone"] as? String ?? ""),
                             website:  (jsonResponse["website"] as? String ?? ""),
                             company: (jsonResponse["company"] as? [String:Any] ?? [:]))
        }
    }
    
    func fetchComments(by postId: Int16) async throws {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let plistData = NSDictionary(contentsOfFile: filePath ?? "")
        let urlString = "\(plistData!["url_user_comments"] as? String ?? "")\(postId)"
        
        guard let url = URL(string: urlString) else {
            throw HttpError.badURL
        }
        
        let commentsResponse: [Comments] = try await httpClient.fetch(url: url)
        
        DispatchQueue.main.async {
            self.comments = commentsResponse
        }
    }
    
}
