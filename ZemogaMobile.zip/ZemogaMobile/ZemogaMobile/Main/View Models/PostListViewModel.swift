//
//  ViewModelList.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 29/05/22.
//

import Foundation

class PostListViewModel {
    var refreshData = { () -> () in }
    
    @Published var posts: [Post] = [] {
        didSet {
            refreshData()
        }
    }
    
    var httpClient: HTTPClientProtocol!
    
    init(httpClient: HTTPClientProtocol){
        self.httpClient = httpClient
    }
    
    func fetchPost() async throws {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let plistData = NSDictionary(contentsOfFile: filePath ?? "")
        let urlString = (plistData!["url_post_list"] as? String)!
        
        guard let url = URL(string: urlString) else {
            throw HttpError.badURL
        }
        
        let postResponse: [Post] = try await httpClient.fetch(url: url)
        
        DispatchQueue.main.async {
            self.posts = postResponse
            self.savePosts()
        }
    }
    
    func savePosts(){
        posts.forEach { post in
            let _post = PostsEntity(context: PersistentContainer.shared.viewContext)
            _post.userId = post.userId
            _post.title = post.title
            _post.postBody = post.body
            _post.idPost = post.id
            _post.isFavorite = 0
            
            do {
                try PersistentContainer.shared.viewContext.saveIfNeeded()
            } catch {
                PersistentContainer.shared.viewContext.delete(_post)
            }
        }
    }
    
    func getFavorites() -> [Post] {
        var _posts: [Post] = []
        let postsEntity = PostsEntity.listAllFavoritesFetchRequest(in: PersistentContainer.shared.viewContext)
        postsEntity.forEach { postEntity in
            _posts.append(Post(userId: postEntity.userId, id: postEntity.idPost, title: postEntity.title, body: postEntity.postBody))
        }
        return _posts
    }
    
    func deleteAllPost() {
        try! PostsEntity.deleteAllInBatch()
    }
}
