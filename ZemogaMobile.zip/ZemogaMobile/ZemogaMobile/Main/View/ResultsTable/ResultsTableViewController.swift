//
//  ResultsTableViewController.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 14/04/22.
//

import UIKit
import CoreData
/**
 ResultsTableViewController
 
 This controller uses `UITableViewDiffableDataSource`, as an object to load the cells and their values:
 */
class ResultsTableViewController: UITableViewController {
    
    var itemsResult = [Item]()
    var itemsFavorites = [Item]()
    var favorites: [Post] = [] {
        didSet {
            loadFavoritePosts()
        }
    }
    var initialSnapshot = NSDiffableDataSourceSnapshot<Section, Item>()
    var fetchedResultsController: NSFetchedResultsController<PostsEntity>
    
    private(set) lazy var dataSource: UITableViewDiffableDataSource<Section, Item> = {
        
        return UITableViewDiffableDataSource<Section, Item>(tableView: tableView) {
            (tableView: UITableView, indexPath: IndexPath, item: Item) -> UITableViewCell? in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "resultTableViewCellId", for: indexPath) as? ResultTableViewCell
            
            cell?.lblTitle.text = item.title
            cell?.lblTitle.widthAnchor.constraint(equalTo: self.tableView.widthAnchor, multiplier: 0.8).isActive = true
            cell?.textLabel?.textAlignment = .center
            let largeConfig = UIImage.SymbolConfiguration(pointSize: 50, weight: .regular, scale: .small)
            
            if Section.allCases[indexPath.section] == .main {
                cell?.img.image = UIImage.init(systemName: "circle.fill", withConfiguration: largeConfig)
            }else{
                cell?.img.image = UIImage.init(systemName: "star.fill", withConfiguration: largeConfig)
            }
            
            return cell
        }
        
    }()
    
    init(fetchedResultsController: NSFetchedResultsController<PostsEntity>) {
        self.fetchedResultsController = fetchedResultsController
        super.init(nibName: "ResultsTableViewController", bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setup()
        try! fetchedResultsController.performFetch()
    }
    
    
    func setup()  {
        let itemCellNib = UINib(nibName: "ResultTableViewCell", bundle: nil)
        self.tableView.register(itemCellNib, forCellReuseIdentifier: "resultTableViewCellId")
        self.dataSource.defaultRowAnimation = .fade
        self.fetchedResultsController.delegate = self
    }
    
    func setupUI()  {
        self.tableView.sectionIndexBackgroundColor = .clear
        self.tableView.sectionIndexTrackingBackgroundColor = .clear
        self.tableView.backgroundColor = UIColor.clear
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let item = dataSource.itemIdentifier(for: indexPath) {
            TableTransitionMediator.instance.sendItemSelected(post: PostsEntity.get(by: item.id, in: PersistentContainer.shared.viewContext))
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsResult.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    //MARK: Manage favorites
    
    func loadAllPosts()  {
        try! fetchedResultsController.performFetch()
    }
    
    func removeData(){
        if !itemsResult.isEmpty {
            initialSnapshot.deleteAllItems()
            itemsResult.removeAll()
            itemsFavorites.removeAll()
            for section in Section.allCases {
                initialSnapshot.appendSections([section])
                if section == .favorites {
                    initialSnapshot.appendItems(self.itemsFavorites)
                } else{
                    initialSnapshot.appendItems(self.itemsResult)
                }
            }
            self.dataSource.apply(initialSnapshot, animatingDifferences: true)
        }
    }
    
    func loadFavoritePosts(){
        itemsFavorites.removeAll()
        favorites.forEach { post in
            self.itemsFavorites.append(Item(title: (post.title),
                                            body: (post.body),
                                            id: (post.id)))
        }
        if !itemsFavorites.isEmpty {
            var initialSnapshot = NSDiffableDataSourceSnapshot<Section, Item>()
            initialSnapshot.appendSections([.favorites])
            initialSnapshot.appendItems(self.itemsFavorites)
            self.dataSource.apply(initialSnapshot, animatingDifferences: true)
        }else{
            TableTransitionMediator.instance.returnError(error: TableError.noDataToShow)
        }
    }
}
