//
//  DiffableDataSources.swift
//  mercadolibre_test
//
//  Created by Nelson Peña on 17/04/22.
//

import Foundation
import CoreData
import UIKit

/// Diffable Data Sources are supported when using a Fetched Results Controller.
/// Simply use the single delegate method available and apply the new snapshot.

extension ResultsTableViewController: NSFetchedResultsControllerDelegate {
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChangeContentWith snapshot: NSDiffableDataSourceSnapshotReference) {
        itemsResult.removeAll()
        itemsFavorites.removeAll()
        var initialSnapshot = NSDiffableDataSourceSnapshot<Section, Item>()
        let snapshot = snapshot as NSDiffableDataSourceSnapshot<String,NSManagedObjectID>
        snapshot.itemIdentifiers.forEach { NSManagedObjectID in
            
            guard let posts = try? PersistentContainer.shared.viewContext.existingObject(with: NSManagedObjectID) as? PostsEntity else { return}
            if posts.isFavorite == 1 {
                self.itemsFavorites.append(loadItemResult(post: posts))
            }else{
                self.itemsResult.append(loadItemResult(post: posts))
            }
            
        }
        for section in Section.allCases {
            initialSnapshot.appendSections([section])
            if section == .favorites {
                initialSnapshot.appendItems(self.itemsFavorites)
            } else{
                initialSnapshot.appendItems(self.itemsResult)
            }
        }
        self.dataSource.apply(initialSnapshot, animatingDifferences: true)
    }
    
    func loadItemResult(post: PostsEntity) -> Item {
        return Item(title: (post.title),
                    body: (post.postBody),
                    id: (post.idPost))
    }
    
}
