//
//  ModalTransitionListener.swift
//  IdApp
//
//  Created by Nelson Peña on 10/1/19.
//  Copyright © 2019 Nelson Peña. All rights reserved.
//

import Foundation

protocol TableTransitionListener {
    func onItemSelected(post: PostsEntity)
    func onError(error: Error)
}

class TableTransitionMediator {
    
    /* Singleton */
    class var instance: TableTransitionMediator {
        struct Static {
            static let instance: TableTransitionMediator = TableTransitionMediator()
        }
        return Static.instance
    }
    
    private var listener: TableTransitionListener?
    
    private init() {
        
    }
    
    func setListener(listener: TableTransitionListener) {
        self.listener = listener 
    }
    
    func sendItemSelected(post: PostsEntity) {
        listener?.onItemSelected(post: post)
    }
    
    func returnError(error: Error) {
        listener?.onError(error: error)
    }
}
