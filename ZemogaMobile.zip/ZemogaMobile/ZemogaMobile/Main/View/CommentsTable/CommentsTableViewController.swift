//
//  CommentsTableViewController.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 31/05/22.
//
import UIKit
import CoreData
/**
 CommentsTableViewController
 
 This controller uses `UITableViewDiffableDataSource`, as an object to load the cells and their values:
 */
class CommentsTableViewController: UITableViewController {
    
    private(set) lazy var dataSource: UITableViewDiffableDataSource<Section, Item> = {
        return UITableViewDiffableDataSource<Section, Item>(tableView: tableView) {
            (tableView: UITableView, indexPath: IndexPath, item: Item) -> UITableViewCell? in
            let cell = tableView.dequeueReusableCell(withIdentifier: "commentsTableViewCellId", for: indexPath) as? CommentsTableViewCell
            cell?.value.text = item.title
            return cell
        }
    }()
    
    var comments:[Comments] = [] {
        didSet {
            reloadData()
        }
    }
    
    init() {
        super.init(nibName: "CommentsTableViewController", bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setup()
    }
    
    func setup() {
        let featureCellNib = UINib(nibName: "CommentsTableViewCell", bundle: nil)
        self.tableView.register(featureCellNib, forCellReuseIdentifier: "commentsTableViewCellId")
        self.dataSource.defaultRowAnimation = .fade
        self.tableView.invalidateIntrinsicContentSize()
    }
    
    func setupUI()  {
        self.tableView.sectionIndexBackgroundColor = .clear
        self.tableView.sectionIndexTrackingBackgroundColor = .clear
        self.tableView.backgroundColor = UIColor.clear
    }

    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    // MARK: Data
    
    func reloadData(name: String = ""){
        var items = [Item]()
        
        comments.forEach { comment in
            items.append(Item(title: comment.body))
        }
        
        var initialSnapshot = NSDiffableDataSourceSnapshot<Section, Item>()
        initialSnapshot.appendSections([.main])
        initialSnapshot.appendItems(items)
        
        self.dataSource.apply(initialSnapshot, animatingDifferences: true)
    }
}
