//
//  CommentsTableViewCell.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 31/05/22.
//

import UIKit

class CommentsTableViewCell: UITableViewCell {

    @IBOutlet var value: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
