//
//  ViewController.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 29/05/22.
//

import UIKit

/**
 PostListViewController
 
 This controller shows the list of results, consuming the url  https://jsonplaceholder.typicode.com/posts.
 
 - important: Two tables are implemented in this class `resultsTableViewController` one dedicated to the lookup control, and one inserted as a child view in a view viewer `containerTable`.
 
 - returns:
 var didSelectRowAction: ((_ postId: (PostsEntity)) -> Void)?
 var onFailedAction: ((Error) -> Void)?
 */
class PostListViewController: UIViewController, Storyboarded  {
    
    @IBOutlet var containerTable: UIView!
    @IBOutlet var indicator: UIActivityIndicatorView!
    @IBOutlet var segmentType: UISegmentedControl!
    @IBOutlet var btnDeleteAll: UIButton!
    
    var didSelectRowAction: ((_ post: (PostsEntity)) -> Void)?
    var onFailedAction: ((Error) -> Void)?
    var viewModel = PostListViewModel(httpClient: HttpClient())
    private lazy var resultsTableViewController = ResultsTableViewController(fetchedResultsController: .postAllFetchedResultsController())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        setupUI()
    }
    
    /// Initial settings on the controller
    func initialSetup()  {
        
        if !PostsEntity.exists(in: PersistentContainer.shared.viewContext) {
            loadIndicator(hide: false)
            fetchPost()
        }else{
            loadIndicator(hide: true)
        }
        dataBind()
        TableTransitionMediator.instance.setListener(listener: self)
    }
    
    func setupUI(){
        title = NSLocalizedString("tittle", comment: "view title")
        configureTableViewResults()
        comfigureSegment()
        configureUIReloadButton()
        btnDeleteAll.setTitle(NSLocalizedString("titleBtnDeteleAll", comment: "button title"), for: .normal)
        btnDeleteAll.addTarget(self, action:  #selector(deleteAllPostInDataBase(_:)), for: .touchUpInside)
    }
    
    @IBAction func deleteAllPostInDataBase(_ sender: UIButton) {
        viewModel.deleteAllPost()
        resultsTableViewController.removeData()
        self.loadIndicator(hide: true)
    }
    
    @IBAction func reloadPost(_ sender: UIButton) {
        if !PostsEntity.exists(in: PersistentContainer.shared.viewContext) {
            self.loadIndicator(hide: false)
            fetchPost()
        }
    }
    
    func loadIndicator(hide isHiden: Bool){
        if !isHiden {
            self.indicator.startAnimating()
        }else{
            self.indicator.stopAnimating()
        }
        self.indicator.isHidden = isHiden
    }
    
    func configureUIReloadButton()  {
        let reloadButton = UIButton(type: .custom)
        reloadButton.setImage(UIImage(systemName: "arrow.clockwise"), for: .normal)
        reloadButton.setTitle("", for: .normal)
        reloadButton.tintColor = .red
        reloadButton.addTarget(self,  action: #selector(reloadPost(_:)), for: .touchUpInside)
        reloadButton.widthAnchor.constraint(equalToConstant: 30).isActive = true
        reloadButton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: reloadButton)
    }
    
    //MARK: segment
    
    func comfigureSegment()  {
        segmentType.selectedSegmentTintColor = UIColor.accentColor
        segmentType.backgroundColor = UIColor.white
        let titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        segmentType.setTitleTextAttributes(titleTextAttributes as [NSAttributedString.Key : Any], for:.normal)
        
        let titleTextAttributes1 = [NSAttributedString.Key.foregroundColor: UIColor.white]
        segmentType.setTitleTextAttributes(titleTextAttributes1 as [NSAttributedString.Key : Any], for:.selected)
        segmentType.removeAllSegments()
        segmentType.insertSegment(withTitle:NSLocalizedString("tittleSegmentPost", comment: "sengment text"), at: 0, animated: false)
        segmentType.insertSegment(withTitle: NSLocalizedString("titleSegmentFavorites", comment: "sengment text"), at: 1, animated: false)
        
        // segment actions
        segmentType.selectedSegmentIndex = 0
        segmentType.addTarget(self, action:  #selector(segmentedControlValueChanged), for:.valueChanged)
    }
    
    @IBAction func segmentedControlValueChanged(_ segment: UISegmentedControl) {
        resultsTableViewController.removeData()
        if(segment.selectedSegmentIndex == 0){
            resultsTableViewController.loadAllPosts()
        }else{
            resultsTableViewController.favorites = viewModel.getFavorites()
        }
    }
    
    // MARK: Painting table
    
    func fetchPost(){
        Task {
            do {
                try await viewModel.fetchPost()
            } catch {
                print("❌ Error: \(error)")
            }
        }
    }
    
    func configureTableViewResults() {
        resultsTableViewController.view.translatesAutoresizingMaskIntoConstraints = false
        if(!containerTable.subviews.contains(resultsTableViewController.view)){
            addChild(resultsTableViewController)
            containerTable.addSubview(resultsTableViewController.view)
            // Create and activate the constraints for the child’s view.
            NSLayoutConstraint.activate([
                resultsTableViewController.view.leadingAnchor.constraint(equalTo: containerTable.leadingAnchor),
                resultsTableViewController.view.trailingAnchor.constraint(equalTo: containerTable.trailingAnchor),
                resultsTableViewController.view.topAnchor.constraint(equalTo: containerTable.topAnchor),
                resultsTableViewController.view.bottomAnchor.constraint(equalTo: containerTable.bottomAnchor)
            ])
            // Notify the child view controller that the move is complete.
            resultsTableViewController.didMove(toParent: self)
        }
    }
    
    
    func dataBind(){
        viewModel.refreshData = { [weak self] () in
            self?.loadIndicator(hide: true)
        }
    }
    
    func configure(didSelectRowAction: ((_ selectedItem: (PostsEntity)) -> Void)? = nil, onFailedAction: ((Error) -> Void)? = nil)  {
        self.didSelectRowAction = didSelectRowAction
        self.onFailedAction = onFailedAction
    }
    
}

extension PostListViewController: TableTransitionListener {
    
    func onItemSelected(post: PostsEntity) {
        didSelectRowAction!(post)
    }
    
    func onError(error: Error) {
        onFailedAction?(error)
    }
}
