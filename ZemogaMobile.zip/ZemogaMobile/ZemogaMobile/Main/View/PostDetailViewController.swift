//
//  FavoriteDetailViewController.swift
//  ZemogaMobile
//
//  Created by Nelson Peña on 30/05/22.
//

import UIKit


/**
 PostDetailViewController
 
 This controller shows the user details,  consuming the url  https://jsonplaceholder.typicode.com/users/.
 
 - important: Two tables are implemented in this class `commentsTableViewController` one dedicated to the lookup control, and one inserted as a child view in a view viewer `containerTableComments`.
 
 */
class PostDetailViewController: UIViewController, Storyboarded {
    
    @IBOutlet var containerTableComments: UIView!
    @IBOutlet var lblDescription: UITextView!
    @IBOutlet var lblCommentsTitle: UILabel!
    @IBOutlet var lblUserTitle: UILabel!
    @IBOutlet var lblDescriptionTitle: UILabel!
    
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblUserEmail: UILabel!
    @IBOutlet var lblUserAddres: UILabel!
    @IBOutlet var lblUserPhone: UILabel!
    @IBOutlet var lblUserWebPague: UILabel!
    @IBOutlet var lblUserCompany: UILabel!
    
    @IBOutlet var lblTittleUserName: UILabel!
    @IBOutlet var lblTittleUserEmail: UILabel!
    @IBOutlet var lblTittleUserAddres: UILabel!
    @IBOutlet var lblTittleUserPhone: UILabel!
    @IBOutlet var lblTittleUserWebPague: UILabel!
    @IBOutlet var lblTittleUserCompany: UILabel!
    
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet private var commentsContainerTableHeightConstraint: NSLayoutConstraint?
    
    var viewModel = PostDetailViewModel(httpClient: HttpClient())
    var postEntity: PostsEntity?
    private lazy var commentsTableViewController = CommentsTableViewController()
    let reloadButton = UIButton(type: .custom)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        setupUI()
    }
    
    func configure(post postEntity: PostsEntity)  {
        self.postEntity = postEntity
    }
    
    /// Initial settings on the controller
    func initialSetup()  {
        lblDescription.text = postEntity?.postBody
        lblDescription.isEditable = false
        configureTableComments()
        fetchUser()
        fetchComments()
        userDataBind()
        commnetsDataBind()
    }
    
    func setupUI(){
        title = NSLocalizedString("tittleDetail", comment: "view title")
        lblCommentsTitle.text =  NSLocalizedString("tittleDetail", comment: "label text")
        lblDescriptionTitle.text =  NSLocalizedString("textDescription", comment: "label text")
        lblUserTitle.text =  NSLocalizedString("textUser", comment: "label text")
        
        lblTittleUserName.text =  NSLocalizedString("textName", comment: "label text")
        lblTittleUserEmail.text =  NSLocalizedString("textEmail", comment: "label text")
        lblTittleUserAddres.text =  NSLocalizedString("textAddres", comment: "label text")
        lblTittleUserPhone.text =  NSLocalizedString("textPhone", comment: "label text")
        lblTittleUserWebPague.text =  NSLocalizedString("textWebPague", comment: "label text")
        lblTittleUserCompany.text =  NSLocalizedString("textCompany", comment: "label text")
        configureAddFavoriteButton()
    }
    
    func configureAddFavoriteButton()  {
        let iconName = postEntity?.isFavorite == 0 ? "star" : "star.fill"
        reloadButton.setImage(UIImage(systemName: iconName), for: .normal)
        reloadButton.setTitle("", for: .normal)
        reloadButton.tintColor = .accentColor
        reloadButton.addTarget(self,  action: #selector(addFavoriteAction(_:)), for: .touchUpInside)
        reloadButton.widthAnchor.constraint(equalToConstant: 30).isActive = true
        reloadButton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: reloadButton)
    }
    
    /// In this table all the attributes of the object are loaded, which were previously obtained from the server by means of the `userid`
    func configureTableComments() {
        if(!containerTableComments.subviews.contains(commentsTableViewController.view)){
            addChild(commentsTableViewController)
            containerTableComments.addSubview(commentsTableViewController.view)
            /// Create and activate the constraints for the child’s view.
            NSLayoutConstraint.activate([
                commentsTableViewController.view.leadingAnchor.constraint(equalTo: containerTableComments.leadingAnchor),
                commentsTableViewController.view.trailingAnchor.constraint(equalTo: containerTableComments.trailingAnchor),
                commentsTableViewController.view.topAnchor.constraint(equalTo: containerTableComments.topAnchor),
                commentsTableViewController.view.bottomAnchor.constraint(equalTo: containerTableComments.bottomAnchor)
            ])
            /// Notify the child view controller that the move is complete.
            commentsTableViewController.view.translatesAutoresizingMaskIntoConstraints = false
            commentsTableViewController.view.autoresizingMask = [.flexibleWidth , .flexibleHeight]
            containerTableComments.autoresizesSubviews = true
            containerTableComments.clipsToBounds = true
            commentsTableViewController.didMove(toParent: self)
        }
    }
    @IBAction func addFavoriteAction(_ sender: UIButton) {
        addNewFavorite()
    }
    
    
    /// Because the parent view is required to contain the same height as the child view.
    ///
    /// in this case since it `Contraints` a `commentsTableViewController`, the constraints of the view are updated, obtaining the height of the table `commentsTableViewController`
    func updateCommentsTableContraints()  {
        self.scrollView.layoutIfNeeded()
        self.view.layoutIfNeeded()
        print(CGFloat(self.commentsTableViewController.tableView.contentSize.height))
        print(self.commentsContainerTableHeightConstraint!.constant)
        self.commentsContainerTableHeightConstraint!.constant = CGFloat(self.commentsTableViewController.tableView.contentSize.height)
    }
    
    func fetchUser(){
        Task {
            do {
                try await viewModel.fetchUser(by: postEntity!.userId)
            } catch {
                print("❌ Error: \(error)")
            }
        }
    }
    
    func fetchComments(){
        Task {
            do {
                try await viewModel.fetchComments(by: postEntity!.idPost)
            } catch {
                print("❌ Error: \(error)")
            }
        }
    }
    
    
    
    func userDataBind(){
        viewModel.refreshUserData = { [weak self] () in
            self?.lblUserName.text =  self?.viewModel.user.name
            self?.lblUserEmail.text =  self?.viewModel.user.email
            self?.lblUserAddres.text =   "\(self?.viewModel.user.address["street"] as! String) \(self?.viewModel.user.address["suite"] as! String) \(self?.viewModel.user.address["city"] as! String)"
            self?.lblUserPhone.text =  self?.viewModel.user.phone
            self?.lblUserWebPague.text =  self?.viewModel.user.website
            self?.lblUserCompany.text = (self?.viewModel.user.company["name"] as! String)
        }
    }
    
    func commnetsDataBind(){
        viewModel.refreshComments = { [weak self] () in
            DispatchQueue.main.async {
                self?.commentsTableViewController.comments = self?.viewModel.comments ?? []
                self?.updateCommentsTableContraints()
                self?.updateViewConstraints()
                
            }
        }
    }
    
    
    func addNewFavorite() {
        postEntity?.isFavorite = 1
        reloadButton.setImage(UIImage(systemName: "star.fill"), for: .normal)
        do {
            try PersistentContainer.shared.viewContext.saveIfNeeded()
        } catch {
            print("❌ error to save favorite")
        }
    }
}
