//
//  Mockable.swift
//  ZemogaMobileTests
//
//  Created by Nelson Peña on 31/05/22.
//

import Foundation

protocol Mockable: AnyObject {
    var bunble: Bundle { get }
    func loadJSON<T: Decodable>(filename: String, type: T.Type) -> [T]
}

extension Mockable {
    var bundle: Bundle {
        return Bundle(for: type(of: self))
    }
    
    func loadJSON<T: Decodable>(filename: String, type: T.Type) -> [T] {
        guard let path = bunble.url(forResource: filename, withExtension: "json") else {
            fatalError("failed to load JSON file.")
        }
        
        do {
            let data = try Data(contentsOf: path)
            let decodeObjet = try JSONDecoder().decode([T].self, from: data)
            return decodeObjet
        }catch {
            print("❌ \(error)")
            fatalError("failed to decode JSON.")
        }
    }
    
    func loadJSON(filename: String) -> [String : Any] {
        guard let path = bunble.url(forResource: filename, withExtension: "json") else {
            fatalError("failed to load JSON file.")
        }
        do {
            let data = try Data(contentsOf: path)
            var jsonData: [String: Any] = [:]
            guard  let jsonResponse = try? JSONSerialization.jsonObject(with:data, options: []) else {
                fatalError("❌ failed to Serialize JSON.")
            }
            if let jData = jsonResponse as? [String: Any] {
                jsonData = jData
            }
            return jsonData
        }catch {
            print("❌ \(error)")
            fatalError("failed to decode JSON.")
        }
    }
    
}
