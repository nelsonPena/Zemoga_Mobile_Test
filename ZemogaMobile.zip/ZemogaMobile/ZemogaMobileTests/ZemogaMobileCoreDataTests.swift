//
//  ZemogaMobileTests.swift
//  ZemogaMobileTests
//
//  Created by Nelson Peña on 29/05/22.
//

import XCTest
@testable import ZemogaMobile

class ZemogaMobileCoreDataTests: XCTestCase {

    func testDeleteAllPost() throws {
        try! PostsEntity.deleteAllInBatch()
        XCTAssert(true)
    }
    
    func testCreatePost() throws {
        let post = PostsEntity(context: PersistentContainer.shared.viewContext)
        post.userId = 1
        post.title = "Texto de prueba título publicación"
        post.postBody = "Texto de prueba cuerpo publicación"
        post.idPost = 3
        post.isFavorite = 1
        
        do {
            XCTAssert(true)
            try PersistentContainer.shared.viewContext.saveIfNeeded()
        } catch {
            PersistentContainer.shared.viewContext.delete(post)
            XCTAssertNoThrow(error)
        }
    }
    
    
    
    
}
