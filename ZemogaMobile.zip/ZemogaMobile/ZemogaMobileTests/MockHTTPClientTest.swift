//
//  ZemogaMobileHTTPClientTest.swift
//  ZemogaMobileTests
//
//  Created by Nelson Peña on 31/05/22.
//

import Foundation
@testable import ZemogaMobile

/**
 MockHTTPClientTest
 Esta clase es una copia o Mock del servicio de consumo rest  donde se implementa el protocolo `HTTPClientProtocol` implementado en la clase  `HttpClient`
 
 - important: Acá se recibe un nombre de archivo para localizar el JSON que nos va a servir como simulador de respuesta del servicio`.
 */
final class MockHTTPClientTest: HTTPClientProtocol, Mockable {
   
    
    var bunble: Bundle
    var filename: String
    
    init(filename: String) {
        self.filename = filename
        self.bunble = Bundle(for: type(of: self))
    }
    
    func fetch<T: Codable>(url: URL) async throws -> [T] {
        return loadJSON(filename: filename, type: T.self)
    }
    
    func fetch(url: URL) async throws -> [String : Any] {
        return loadJSON(filename: filename)
    }
}
