//
//  PostListViewModelTest.swift
//  ZemogaMobileTests
//
//  Created by Nelson Peña on 31/05/22.
//

import XCTest
import Combine
@testable import ZemogaMobile

class DetailPostViewModelTest: XCTestCase {
    
    var detailPostVM: PostDetailViewModel!
    private var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        cancellables = []
    }
    
    override class func tearDown() {
        super.tearDown()
    }
    
    // En esta prueba unitaria se ejecuta el listado de publicaciones inicial, simulando un servidor de Internet local, leyendo un archivo JSON previamente cargado con la estructura exacta a la del consumo.
    func testFechtDetailSuccesssfully() async throws  {
        detailPostVM = PostDetailViewModel(httpClient: MockHTTPClientTest(filename: "UserDetailResponse"))
        let expectation = XCTestExpectation(description: "feched user")
        
        try await detailPostVM.fetchUser(by: 1)
        
        detailPostVM
            .$user
            .dropFirst()
            .sink{ value in
                XCTAssertTrue(value.id > 0)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 1)
        
    }

    // En esta prueba unitaria se ejecuta el listado de publicaciones inicial, simulando un servidor de Internet local, leyendo un archivo JSON previamente cargado con la estructura exacta a la del consumo.
    func testFechtCommentsSuccesssfully() async throws  {
        detailPostVM = PostDetailViewModel(httpClient: MockHTTPClientTest(filename: "CommentsResponse"))
        let expectation = XCTestExpectation(description: "feched posts")
        
        try await detailPostVM.fetchComments(by: 1)
        
        detailPostVM
            .$comments
            .dropFirst()
            .sink{ value in
                XCTAssertTrue(value.count > 0)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 1)
    }
    
    
}
