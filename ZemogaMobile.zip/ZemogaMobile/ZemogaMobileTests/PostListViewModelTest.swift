//
//  PostListViewModelTest.swift
//  ZemogaMobileTests
//
//  Created by Nelson Peña on 31/05/22.
//

import XCTest
import Combine
@testable import ZemogaMobile

class PostListViewModelTest: XCTestCase {

    var postListVM: PostListViewModel!
    private var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        postListVM = PostListViewModel(httpClient: MockHTTPClientTest(filename: "PostResponse"))
        cancellables = []
    }
 
    override class func tearDown() {
        super.tearDown()
    }

    // En esta prueba unitaria se ejecuta el listado de publicaciones inicial, simulando un servidor de Internet local, leyendo un archivo JSON previamente cargado con la estructura exacta a la del consumo.
    func testFechtPostSuccesssfully() async throws  {
   
        let expectation = XCTestExpectation(description: "feched posts")
        
        try await postListVM.fetchPost()
        
        postListVM
            .$posts
            .dropFirst()
            .sink{ value in
                XCTAssertTrue(value.count > 0)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 1)
    }
    
}
